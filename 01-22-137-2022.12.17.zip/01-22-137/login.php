<?php
session_start();
?>

<!DOCTYPE html>
<head>
    <title>php</title>
<head>

<body>
    <?php 
        require 'pages/header.php';
        require 'pages/date.php';
        require 'pages/login_code.php';
    ?>
<body>