<?php
echo '
    <center> Date:   ' . date("D:M:Y") . '</center><hr>
';