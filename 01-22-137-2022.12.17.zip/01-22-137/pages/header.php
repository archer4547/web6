<header>
    
    <div style="display: flex;">
        
        <div style="flex-grow: 2;">
            <a href="index.php">
                <button style="height: 100%; width: 100%;">
                    main page
                </button>
            </a>
        </div>
        
        <div style="flex-grow: 2;">
            <a href="not_index.php">
                <button style="height: 100%; width: 100%;">
                    not the main page
                </button>
            </a>
        </div>

        <div style="flex-grow: 1;">
            <a href="login.php">
                <button style="height: 100%; width: 100%;">
                    login / register
                </button>
            </a>
        </div>
    
    </div>

</header>