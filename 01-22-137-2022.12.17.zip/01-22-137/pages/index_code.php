<div style="display: flex;">
    
    <div style="flex-grow: 1; margin-top: 5vh">
        <center> some <br> content <br> there </center>
    </div>

    <div style="flex-grow: 1; margin-top: 5vh">
        <center> and <br> there </center>
    </div>

</div>

<hr>

<form action="comments/index_post.php" method="post">
    Comment: <input type="text" name="comment" required>
    <br>
    <input type="submit" value="Submit">
</form>

<br>