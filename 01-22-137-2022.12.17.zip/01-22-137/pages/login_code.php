<div style="display: flex;">
    
    <div style="flex-grow: 1;">
        <center>

            <form action="pages/reg_login.php" method="post">
                <table style="width: 10vw;">
                    <tr><td>Name: <input name="name" type="text"></td></tr>
                    <tr><td>E-mail: <input name="email" type="email"></td></tr>
                    <tr><td>Password: <input name="pass" type="text"></td></tr>
                    <tr><td><center><input type="submit" name="register" value="Register"></center></td></tr>
                </table>
            </form>

        </center>
    </div>

    <div style="flex-grow: 1;">
        <center>

            <form action="pages/reg_login.php" method="post">
                <table style="width: 10vw;">
                    <tr><td>E-mail: <input name="email_l" type="email"></td></tr>
                    <tr><td>Password: <input name="pass_l" type="text"></td></tr>
                    <tr><td><center><input type="submit" name="login" value="Login"></center></td></tr>
                </table>
            </form>
            
        </center>
    </div>

</div>