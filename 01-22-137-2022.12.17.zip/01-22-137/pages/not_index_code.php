<div style="display: flex;">
        
    <div style="flex-grow: 1; margin-top: 5vh">
        <center> there is <br> nothing interesting </center>
    </div>

    <div style="flex-grow: 1; margin-top: 5vh">
        <center> just php <br> functionality </center>
    </div>

</div>

<hr>

<form action="comments/not_index_post.php" method="post">
    Comment: <input type="text" name="comment">
    <br>
    <input type="submit" value="Submit">
</form>

<br>